package test.redis.example;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.concurrent.CountDownLatch;
import redis.clients.jedis.Jedis;
import redis.clients.jedis.JedisPubSub;
/**
 *
 * @author thachlp
 */
public class RedisSample {
    public static Map<String, String> puttoMap(Account account) {
        Map<String, String> hash = new HashMap<>();
        hash.put("username", account.getUserName());
        hash.put("password", account.getPassWord());
        return hash;
    }
    public static void main(String[] args) throws InterruptedException {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        System.out.println("Connection to server successfully");
        //check whether server is running or not
        System.out.println("Server is running: " + jedis.ping());




    }
}