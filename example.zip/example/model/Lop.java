package test.redis.example.model;

import redis.clients.jedis.Jedis;

import java.time.Year;
import java.util.Date;

public class Lop {
    private Integer SoSinhVien;
    private String TenLop;

    public  Lop(String tenLop){
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        this.TenLop = tenLop;
        this.SoSinhVien = Integer.parseInt(jedis.get(tenLop));
    }

    public Lop(String tenLop,Integer soSinhVien) {
        this.TenLop = tenLop;
        this.SoSinhVien = soSinhVien;

        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        jedis.set(this.TenLop,this.SoSinhVien.toString());
    }

    public Lop() {
    }


    public Integer getSoSinhVien() {
        return SoSinhVien;
    }
    public void setSoSinhVien(Integer soSinhVien) {
        SoSinhVien = soSinhVien;
    }
    public void setTenLop(String tenLop) {
        TenLop = tenLop;
    }
    public String getTenLop() {
        return TenLop;
    }





    public void ThemSinhVien() {
        this.SoSinhVien++;
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        jedis.incr(this.TenLop);
    }

    public void XoaSinhVien() {
        this.SoSinhVien--;
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        jedis.decr(this.TenLop);
    }


    public static void main(String[] args) {
        //Lop test = new Lop("MT14-KH03",0);
        //System.out.println(test.getSoSinhVien());

    }


}
