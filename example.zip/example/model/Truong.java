package test.redis.example.model;

public class Truong {
    private Integer SoSinhVien;
    private Integer SoLop;

    public void update() {

    }

}
