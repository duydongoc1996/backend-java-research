package test.redis.example.model;

import redis.clients.jedis.Jedis;

import java.time.Year;
import java.util.List;

public class SinhVien {
    private String MSSV;
    private String TenSinhVien;
    private String NamSinh;
    private String LopHoc;

    public SinhVien() {
    }

    public SinhVien(String MSSV, String TenSinhVien, String NamSinh, String LopHoc) {
        this.MSSV = MSSV;
        this.TenSinhVien = TenSinhVien;
        this.NamSinh = NamSinh;
        this.LopHoc = LopHoc;

    }

    public SinhVien(String mssv){
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        List<String> list = jedis.lrange(mssv,0,-1);
        SinhVien newSinhVien = new SinhVien();

        this.MSSV = mssv;
        this.TenSinhVien = list.get(0);
        this.NamSinh = list.get(1);
        this.LopHoc = list.get(2);
    }


    public void ThemSinhVien() {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        jedis.rpush(this.MSSV,this.TenSinhVien);
        jedis.rpush(this.MSSV,this.NamSinh);
        jedis.rpush(this.MSSV,this.LopHoc);

        Lop lop = new Lop(this.LopHoc);
        lop.ThemSinhVien();
    }

    public void XoaSinhVien() {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        jedis.del(this.MSSV);

        Lop lop = new Lop(this.LopHoc);
        lop.XoaSinhVien();
    }

    public void SuaSinhVien() {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        jedis.lset(this.MSSV,0,this.TenSinhVien);
        jedis.lset(this.MSSV,1,this.NamSinh);
        jedis.lset(this.MSSV,2,this.LopHoc);

    }


    public static void main(String[] args) {
//        Lop lop1 =  new Lop("MT14-KH01");
//        SinhVien b = new SinhVien("1410552","Duyen",Year.parse("1996"),lop1);
//        b.ThemSinhVien();


        //SinhVien test = new SinhVien("1410551");
        //System.out.println(test);

        //test.XoaSinhVien();
    }


    public String getMSSV() {
        return MSSV;
    }

    public void setMSSV(String MSSV) {
        this.MSSV = MSSV;
    }

    public String getTenSinhVien() {
        return TenSinhVien;
    }

    public void setTenSinhVien(String tenSinhVien) {
        TenSinhVien = tenSinhVien;
    }

    public String getNamSinh() {
        return NamSinh;
    }

    public void setNamSinh(String namSinh) {
        NamSinh = namSinh;
    }

    public String getLopHoc() {
        return LopHoc;
    }

    public void setLopHoc(String lopHoc) {
        LopHoc = lopHoc;
    }
}
