package test.redis.example.dao;


import org.springframework.stereotype.Repository;
import redis.clients.jedis.Jedis;
import test.redis.example.model.Lop;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Repository
public class LopDAO {

    public List<Lop> getAllLop() {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        Set<String> listTenLop = jedis.keys("[A-Za-z]*");
        List<Lop> listLop = new ArrayList<>();

        for (String tenLop: listTenLop) {
            listLop.add(new Lop(tenLop));
            //System.out.println(tenLop);
            //System.out.println(new Lop(tenLop).getSoSinhVien());

        }
        return listLop;

    }

    public Lop getLop(String className) {
        return new Lop(className);
    }

    public Lop addLop(Lop newLop) {
        return new Lop(newLop.getTenLop(),0);
    }

    public void deleteLop(String className) {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");
        jedis.del(className);
    }

    public static void main(String[] args){

        List<Lop> listLop = new LopDAO().getAllLop();




//        for (Lop lop:listLop
//             ) {
//            System.out.println("Lop: "+lop.getTenLop() + " - " +lop.getSoSinhVien());
//        }
    }
}
