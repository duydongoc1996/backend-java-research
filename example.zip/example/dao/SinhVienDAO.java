package test.redis.example.dao;


import org.springframework.stereotype.Repository;
import redis.clients.jedis.Jedis;
import test.redis.example.model.Lop;
import test.redis.example.model.SinhVien;

import java.time.Year;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

@Repository
public class SinhVienDAO {


    public List<SinhVien> getAllSinhVien() {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        List<SinhVien> listAllSinhVien = new ArrayList<>();

//        SinhVien b = new SinhVien("1410552");
//        listAllSinhVien.add(b);

        Set<String> listSV = jedis.keys("[0-9]*");

        for (String mssv : listSV) {
            List<String> detail = jedis.lrange(mssv,0,-1);
            listAllSinhVien.add(new SinhVien(mssv,detail.get(0),detail.get(1),detail.get(2)));
        }

        return listAllSinhVien;
    }


    public List<SinhVien> getAllSinhVien(String className) {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        List<test.redis.example.model.SinhVien> listAllSinhVien = new ArrayList<>();

//        SinhVien b = new SinhVien("1410552");
//        listAllSinhVien.add(b);

        Set<String> listSV = jedis.keys("[0-9]*");

        for (String mssv : listSV) {
            List<String> detail = jedis.lrange(mssv,0,-1);
            //System.out.print(detail.get(2));
            if (detail.get(2).equals(className))
                listAllSinhVien.add(new test.redis.example.model.SinhVien(mssv,detail.get(0),detail.get(1),detail.get(2)));
        }

        return listAllSinhVien;
    }

    public SinhVien getSinhVien(String mssv) {
        return new SinhVien(mssv);
    }


    public void deleteSinhVien(String mssv){
        SinhVien del = new SinhVien(mssv);
        del.XoaSinhVien();
    }

    public SinhVien addSinhVien(SinhVien newSinhVien) {
        //Connecting to Redis server on localhost
        Jedis jedis = new Jedis("localhost");

        Boolean checkClass = jedis.exists(newSinhVien.getLopHoc());

        if (!checkClass) {
             new Lop(newSinhVien.getLopHoc(),0);
        }

        newSinhVien.ThemSinhVien();
        return newSinhVien;
    }

    public SinhVien updateSinhVien(SinhVien newSinhVien) {
        newSinhVien.SuaSinhVien();
        return newSinhVien;
    }


    public static void main(String[] args) {
        List<SinhVien> list = new SinhVienDAO().getAllSinhVien("MT14-KH01");
        //String a = "\"all sinh vien\"";
        for (SinhVien sv: list) {
            System.out.println(sv.getMSSV());
        }
    }
}
