package test.redis.example.controller;

import java.util.List;

import org.springframework.http.MediaTypeEditor;
import test.redis.example.dao.LopDAO;
import test.redis.example.dao.SinhVienDAO;
import test.redis.example.model.Employee;
import test.redis.example.dao.EmployeeDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;
import test.redis.example.model.Lop;
import test.redis.example.model.SinhVien;

import javax.print.attribute.standard.Media;

@RestController

public class MainRESTController {

    @Autowired
    private EmployeeDAO employeeDAO;
    private SinhVienDAO sinhvienDAO = new SinhVienDAO();
    private LopDAO lopDAO = new LopDAO();

    @RequestMapping("/")
    @ResponseBody
    public String welcome() {
        return "Welcome to RestTemplate Example.";
    }

    // URL:
    // http://localhost:8080/SomeContextPath/employees
    // http://localhost:8080/SomeContextPath/employees.xml
    // http://localhost:8080/SomeContextPath/employees.json
    @RequestMapping(value = "/employees", //
            method = RequestMethod.GET, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public List<Employee> getEmployees() {
        List<Employee> list = employeeDAO.getAllEmployees();
        return list;
    }

    // URL:
    // http://localhost:8080/SomeContextPath/employee/{empNo}
    // http://localhost:8080/SomeContextPath/employee/{empNo}.xml
    // http://localhost:8080/SomeContextPath/employee/{empNo}.json
    @RequestMapping(value = "/employee/{empNo}", //
            method = RequestMethod.GET, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public Employee getEmployee(@PathVariable("empNo") String empNo) {
        return employeeDAO.getEmployee(empNo);
    }

    // URL:
    // http://localhost:8080/SomeContextPath/employee
    // http://localhost:8080/SomeContextPath/employee.xml
    // http://localhost:8080/SomeContextPath/employee.json

    @RequestMapping(value = "/employee", //
            method = RequestMethod.POST, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public Employee addEmployee(@RequestBody Employee emp) {

        System.out.println("(Service Side) Creating employee: " + emp.getEmpNo());

        return employeeDAO.addEmployee(emp);
    }

    // URL:
    // http://localhost:8080/SomeContextPath/employee
    // http://localhost:8080/SomeContextPath/employee.xml
    // http://localhost:8080/SomeContextPath/employee.json
    @RequestMapping(value = "/employee", //
            method = RequestMethod.PUT, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public Employee updateEmployee(@RequestBody Employee emp) {

        System.out.println("(Service Side) Editing employee: " + emp.getEmpNo());

        return employeeDAO.updateEmployee(emp);
    }

    // URL:
    // http://localhost:8080/SomeContextPath/employee/{empNo}
    @RequestMapping(value = "/employee/{empNo}", //
            method = RequestMethod.DELETE, //
            produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public void deleteEmployee(@PathVariable("empNo") String empNo) {

        System.out.println("(Service Side) Deleting employee: " + empNo);

        employeeDAO.deleteEmployee(empNo);
    }


    @RequestMapping(value = "/students",
            method = RequestMethod.GET,
            //produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public List<SinhVien> getAllSinhVien() {
        List<SinhVien> list = sinhvienDAO.getAllSinhVien();
        return list;
    }

    @RequestMapping(value = "/student/{stdNo}",
            method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public SinhVien getSinhVien(@PathVariable("stdNo") String stdNo) {
        return sinhvienDAO.getSinhVien(stdNo);
    }

    @RequestMapping(value = "/student/{stdNo}",
            method = RequestMethod.DELETE,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public void deleteSinhVien(@PathVariable("stdNo") String stdNo) {
        sinhvienDAO.deleteSinhVien(stdNo);
    }


    @RequestMapping(value = "/students/{className}",
            method = RequestMethod.GET,
            //produces = { MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public List<SinhVien> getAllSinhVien(@PathVariable("className") String className) {
        List<SinhVien> list = sinhvienDAO.getAllSinhVien(className);
        return list;
    }

    @RequestMapping(value = "/student", //
            method = RequestMethod.POST, //
            produces = { MediaType.APPLICATION_JSON_VALUE, //
                    MediaType.APPLICATION_XML_VALUE })
    @ResponseBody
    public SinhVien addSinhVien(@RequestBody SinhVien sv) {

        System.out.println("(Service Side) Creating SinhVien(): " + sv.getMSSV());

        return sinhvienDAO.addSinhVien(sv);
    }


    @RequestMapping(value = "/student",
            method = RequestMethod.PUT,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public SinhVien updateSinhVien(@RequestBody SinhVien sv) {

        System.out.println("(Server side) Updating SinhVien(): " + sv.getMSSV());

        return sinhvienDAO.updateSinhVien(sv);

    }


    @RequestMapping(value = "/classes",
            method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public List<Lop> getAllLop() {
        List<Lop> listLop = lopDAO.getAllLop();
        return listLop;
    }

    @RequestMapping(value = "/class/{className}",
            method = RequestMethod.GET,
            produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public Lop getLop(@PathVariable String className) {
        return lopDAO.getLop(className);
    }


    @RequestMapping(value = "/class",
            method = RequestMethod.POST,
            produces = {MediaType.APPLICATION_JSON_VALUE, MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public Lop addLop(@RequestBody Lop newLop) {
        return lopDAO.addLop(newLop);
    }

    @RequestMapping(value = "/class/{className}",
            method = RequestMethod.DELETE,
            produces = {MediaType.APPLICATION_JSON_VALUE,MediaType.APPLICATION_XML_VALUE})
    @ResponseBody
    public void deleteLop(@PathVariable String className) {
        lopDAO.deleteLop(className);
    }


}